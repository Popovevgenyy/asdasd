﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class ClassReg
    {
        public static string Login { get; set; } = "1";
        public static string Password { get; set; } = "1";

        public static string ReturnDataLogin(string login, string password)
        {

            if (login == Login && password == Password)
            {
                return "Здравствуйте, пользователь ";

            }
            else
            {
                return "Такого пользователя нет!";
            }
        }

        public static string RegDataUser(string login, string password)
        {
            Login = login;
            Password = password;
            return "Пользователь создан!";
        }
    }
}